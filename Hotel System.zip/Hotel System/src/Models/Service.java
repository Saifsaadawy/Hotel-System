package Models;

public class Service { 
    private String name; 
    private String description;
    private double price; 
    public Service(String name, String description, double price) {
        this.name = name; 
        this.description = description; 
        this.price = price; 
        
    }
} // Getters and Setters }