package Models;
 public class Customer { 
    private int id; 
    private String name; 
    private String phone; 
    private String nationality; 
    public Customer(int id, String name, String phone, String nationality) { 
        this.id = id; 
        this.name = name; 
        this.phone = phone; 
        this.nationality = nationality;
    } 

} // Getters and Setters }
