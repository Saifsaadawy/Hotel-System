package Models;
public class Employee { 
    private int id; 
    private String name; 
    private String phone; 
    private String position; 
    public Employee(int id, String name, String phone, String position) 
    { 
        this.id = id; 
        this.name = name; 
        this.phone = phone; 
        this.position = position;
    }
} // Getters and Setters }