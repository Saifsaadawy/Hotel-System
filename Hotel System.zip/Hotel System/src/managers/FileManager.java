import java.io.*; 
import java.util.*;

public class FileManager { 
    public static ArrayList<Employee> employees = new ArrayList<>(); 
    public static ArrayList<Customer> customers = new ArrayList<>();
    public static ArrayList<Room> rooms = new ArrayList<>(); 
    public static ArrayList<Service> services = new ArrayList<>(); 
    public static ArrayList<Reservation> reservations = new ArrayList<>(); 
    // Load + Save methods (same as previous implementation) 
}