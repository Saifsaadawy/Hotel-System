package ui;

import javax.swing.*; 
public class RoomPanel extends JPanel { 
    public RoomPanel() { 
        add(new JLabel("Room Management")); 
    } 
}