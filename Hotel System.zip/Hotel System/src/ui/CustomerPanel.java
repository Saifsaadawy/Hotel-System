package ui;

import javax.swing.*; 
public class CustomerPanel extends JPanel { 
    public CustomerPanel() { 
        add(new JLabel("Customer Module")); 
    } 
}