package ui;

import javax.swing.*; 
public class ServicePanel extends JPanel { 
    public ServicePanel() { 
        add(new JLabel("Service Module")); 
    } 
}