package ui;

import javax.swing.*; 
public class EmployeePanel extends JPanel { 
    public EmployeePanel() { 
        add(new JLabel("Employee Module")); 

    } 
}