package ui;

import javax.swing.*; 
public class ReservationPanel extends JPanel { 
    public ReservationPanel() { 
        add(new JLabel("Reservation Module")); 
    } 
}